<div class="card shadow-sm my-2 ia-card">
    <div class="card-body">
        <h3 class="card-title h4 ia-title"><?= $t['ia_title']; ?></h3>
        <div class="ia-body <?= e_attr($t->get('ia_body_class')); ?>"><?= $t['ia_body']; ?></div>
    </div>
</div>
