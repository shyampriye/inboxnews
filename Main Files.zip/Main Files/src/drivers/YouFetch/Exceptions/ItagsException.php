<?php

namespace MirazMac\YouFetch\Exceptions;

/**
* ItagsException
*
* @package MirazMac\YouFetch
*/
class ItagsException extends \Exception
{
}
