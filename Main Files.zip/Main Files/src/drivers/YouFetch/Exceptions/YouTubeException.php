<?php

namespace MirazMac\YouFetch\Exceptions;

/**
* YouTubeException
*
* @package MirazMac\YouFetch
*/
class YouTubeException extends \Exception
{
}
