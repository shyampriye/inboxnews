<ul class="nav flex-column sticky-top pl-0">
    <?=sp_render_sidebar_menu()?>
</ul>
